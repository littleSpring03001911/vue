<template>
    <h1>
        404<br>页面未找到
    </h1>
</template>
<style scoped>
   h1{
       margin-top: 300px
   }
</style>

